package ph.com.alliance.dao.impl;

import java.util.List;

import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.TransactionRequiredException;

import org.mockito.internal.matchers.Find;
import org.springframework.stereotype.Repository;

import ph.com.alliance.dao.UserDao;
import ph.com.alliance.entity.SpecificSchedule;
import ph.com.alliance.entity.User;

/**
 * Sample data access object implementation using Java Persistence API.
 *
 */
@Repository("userDao")
public class UserDaoImpl implements UserDao {

	@Override
	public List<User> getUserList(EntityManager entityManager) {
		Query query = entityManager.createQuery("FROM User WHERE deleted_flag = 0"); // Select
																						// *
																						// From
		// User
		List<User> userList = query.getResultList();
		return userList;
	}

	@Override
	public boolean findUser(EntityManager entityManager, String email, String password) {
		Query query = entityManager.createQuery("FROM User u WHERE u.email=:email AND u.password=:password");
		query.setParameter("email", email);
		query.setParameter("password", password);

		boolean userExists;

		List<User> user_info = query.getResultList();

		if (user_info != null) {
			userExists = true;

		} else {

			userExists = false;
		}
		return userExists;
	}

	@Override
	public void insert(EntityManager entityManager, User userObject) {

		EntityTransaction transaction = entityManager.getTransaction();
		try {
			transaction.begin();
			entityManager.persist(userObject);
			transaction.commit();
		} catch (Exception e) {

			transaction.rollback();

		}
	}

	@Override
	public User getUser(EntityManager entityManager, int id) {

		Query query = entityManager.createQuery("FROM User u WHERE u.id = :id");
		query.setParameter("id", id);

		return (User) query.getSingleResult();
	}

	@Override
	public void update(EntityManager entityManager, User userObject) {

		EntityTransaction transaction = entityManager.getTransaction();
		try {
			transaction.begin();
			entityManager.persist(userObject);
			transaction.commit();
		} catch (Exception e) {

			transaction.rollback();

		}

	}

}
