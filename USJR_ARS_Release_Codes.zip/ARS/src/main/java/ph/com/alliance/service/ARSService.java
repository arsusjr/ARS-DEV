package ph.com.alliance.service;

import java.util.Collection;
import java.util.List;

import javax.persistence.EntityManager;

import ph.com.alliance.entity.Aircon;
import ph.com.alliance.entity.SpecificSchedule;
import ph.com.alliance.entity.User;

/**
 * 
 * 
 */
public interface ARSService {

	public List<Aircon> getAirconList();

	public void insert(Aircon airconObject);

	/**----------------- MODULE 1 -----------------**/
	
	public boolean findUser(String email, String password);
	
	/**----------------- MODULE 2 -----------------**/
	
	public List<User> getUserList();
	public void insert(User userObject);
	public User getUser(int id);
	public void update(User userObject);
	public void delete(int id);

	/**----------------- MODULE 4 -----------------**/
	
	public List<SpecificSchedule> getSpecificScheduleList();
	public SpecificSchedule getSchedule(int id);
	
	
}
